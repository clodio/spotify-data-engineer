# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

# Date courante pour le stockage
from datetime import datetime
current_datetime = datetime.now().strftime('%Y-%m-%dT%H:%M:%SZ')

# Read recipe inputs
df_spotify_retieved_datas_claude = dataiku.Dataset("df_spotify_retieved_datas_claude_1")
df_spotify_retieved_datas_claude_df = df_spotify_retieved_datas_claude.get_dataframe()
df_playlist_artist_inout_old = dataiku.Dataset("df_playlist_artist_inout_old")
df_playlist_artist_inout_old_df = df_playlist_artist_inout_old.get_dataframe()


# Compute recipe outputs

# supprime les doublons
df_spotify_retieved_datas_claude_df = df_spotify_retieved_datas_claude_df[['artist_id','artist_name','playlist_id','playlist_name']].drop_duplicates()
df_spotify_retieved_datas_claude_df['date']=current_datetime
df_spotify_retieved_datas_claude_df['status']='stay'

# recherche des anciens artistes dans les playlists
df_artist_to_be_out = pd.merge(df_playlist_artist_inout_old_df, df_spotify_retieved_datas_claude_df, how='left', on=['artist_id','playlist_id'], suffixes=('', '_new'), indicator=True).query('_merge == "left_only"').drop('_merge',axis=1)
df_artist_to_be_out.drop(df_artist_to_be_out.filter(regex='_new$').columns, axis=1, inplace=True)
df_artist_to_be_out = df_artist_to_be_out[['artist_id','artist_name','playlist_id','playlist_name','status']]
df_artist_to_be_out = df_artist_to_be_out[df_artist_to_be_out.status != 'out']
df_artist_to_be_out['date']=current_datetime
df_artist_to_be_out['date'] = pd.to_datetime(df_artist_to_be_out['date'])
df_artist_to_be_out['status']='out'

# recherche des nouveaux artistes dans les playlists
df_artist_to_be_in = pd.merge(df_playlist_artist_inout_old_df,df_spotify_retieved_datas_claude_df, how='right', on=['artist_id','playlist_id'], suffixes=('_old', ''), indicator=True).query('_merge == "right_only"').drop('_merge',axis=1)
df_artist_to_be_in.drop(df_artist_to_be_in.filter(regex='_old$').columns, axis=1, inplace=True)
df_artist_to_be_in = df_artist_to_be_in[['artist_id','artist_name','playlist_id','playlist_name']]
df_artist_to_be_in['date']=current_datetime
df_artist_to_be_in['date'] = pd.to_datetime(df_artist_to_be_in['date'])
df_artist_to_be_in['status']='in'

# recherche des artistes déjà présents dans les playlists
df_artist_to_stay= pd.merge(df_playlist_artist_inout_old_df,df_spotify_retieved_datas_claude_df, how='inner', on=['artist_id','playlist_id'], suffixes=('_old', ''), indicator=True)
df_artist_to_stay = df_artist_to_stay[['artist_id','artist_name','playlist_id','playlist_name']]
df_artist_to_stay['date']=current_datetime
df_artist_to_stay['date'] = pd.to_datetime(df_artist_to_stay['date'])
df_artist_to_stay['status']='stay'

# dataset final à inserer en base de données
df_artist_to_insert_df = pd.concat([ df_artist_to_be_out, df_artist_to_be_in, df_artist_to_stay], ignore_index=True)

# Write recipe outputs
df_artist_to_insert = dataiku.Dataset("df_artist_to_insert")
df_artist_to_insert.write_with_schema(df_artist_to_insert_df)
