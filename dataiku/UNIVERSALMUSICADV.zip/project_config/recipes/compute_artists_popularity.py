# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu
# Date courante pour le stockage
from datetime import datetime
current_datetime = datetime.now().strftime('%Y-%m-%dT%H:%M:%SZ')


# Read recipe inputs
df_spotify_retieved_datas_claude = dataiku.Dataset("df_spotify_retieved_datas_claude_1")
df_spotify_retieved_datas_claude_df = df_spotify_retieved_datas_claude.get_dataframe()

df_artist_popularity = df_spotify_retieved_datas_claude_df[['artist_id','artist_name', 'artist_popularity']].drop_duplicates()
df_artist_popularity['date']=current_datetime
df_artist_popularity = df_artist_popularity.rename(columns={"artist_popularity": "popularity"})



# Write recipe outputs
artists_popularity = dataiku.Dataset("artists_popularity")
artists_popularity.write_with_schema(df_artist_popularity)
